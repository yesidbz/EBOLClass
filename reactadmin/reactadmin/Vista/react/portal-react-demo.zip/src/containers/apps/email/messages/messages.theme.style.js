const styles = theme => ({
  'portal-thread': {
    margin: 16
  },
  'portal-thread__header': {
    borderBottom: '1px solid rgba(0, 0, 0, 0.12)',
    flexWrap: 'wrap'
  }
});

export default styles;
